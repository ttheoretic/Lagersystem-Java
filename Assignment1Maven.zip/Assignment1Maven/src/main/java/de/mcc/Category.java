package de.mcc;

public enum Category {
    ELECTRONICS,
    CLOTHING,
    OTHER,
    FOOD,
    TOOLS
}
